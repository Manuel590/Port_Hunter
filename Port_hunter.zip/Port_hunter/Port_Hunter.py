

# Made by Manuel Dos Santos on 13/04/2021. 
# This port hunter will help you to scan open ports on your network just like nmap with the aim of providing accurate results. 
# However, this tool will be updated from time to time so as to provide better and meticulous performance.

import socket
import termcolor

def scan(target, ports):
	print('\n' + 'Starting scan for ' + str(target))
	for port in range(1, ports):
		scan_port(target, port)

def scan_port(ipaddress, port):
	try:
		sock = socket.socket()
		sock.connect((ipaddress, port))
		print("[*] Number of open ports " + str(port))
		sock.close()
	except:
		pass

targets = input("[*] Please enter the target to be scanned (split them by ','): ")
ports = int(input("[*] Please enter the number of ports to be scanned: "))
if ','in targets:
	print(termcolor.colored(("[*] Scanning targets"), 'blue'))
for ip_addr in targets.split(','):
	scan(ip_addr.strip(' '), ports)
else:
	scan(targets, ports) 
